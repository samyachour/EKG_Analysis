#define NO_IMPORT_ARRAY
#define PY_ARRAY_UNIQUE_SYMBOL _scipy_sparse_sparsetools_ARRAY_API

#include "sparsetools.h"
#include "dia.h"
#include "csgraph.h"
#include "coo.h"

extern "C" {
#include "other_impl.h"
}
